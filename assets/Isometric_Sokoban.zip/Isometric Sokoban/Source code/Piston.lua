Piston = Class{}

function Piston:init(x, y, z, dx, dy, dz, key)
    self.x = x
    self.y = y
    self.z = z
    self.dx = dx
    self.dy = dy
    self.dz = dz
    self.key = key
end