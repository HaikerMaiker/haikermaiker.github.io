Switch = Class{}

function Switch:init(x, y, z, key)
    self.x = x
    self.y = y
    self.z = z
    self.key = key
end
